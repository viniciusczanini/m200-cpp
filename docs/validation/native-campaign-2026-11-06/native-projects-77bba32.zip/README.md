# TM200CE40T experimental native projects

These fourteen exact files were saved and freshly reopened in Schneider
EcoStruxure Machine Expert Basic1.4 build484 with No error.
Copy a .smbp from projects/ and open it in the official software to inspect Ladder.
The source/ folder contains unchanged C++ examples; use the repository compiler
and SDK at commit77bba32 to rebuild with an authentic TM200CE40T template.

Editor acceptance is separate from simulator and physical-controller validation.
Seven composed profiles have partial simulator observations; four were not run
in the final bounded session. The three observation probes have unknown runtime
outcomes. Check the repository's NATAL-DELIVERY.md and RUNTIME-RESULTS.md.
Physical PLC transfer, loads and real communication were not tested.
No upload, download, firmware update or output action is performed by this ZIP.

Repository: https://github.com/viniciusczanini/m200-cpp
